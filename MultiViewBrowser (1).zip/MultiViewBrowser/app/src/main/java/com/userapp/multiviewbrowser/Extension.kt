package com.userapp.multiviewbrowser

import org.json.JSONObject
import java.util.UUID

/**
 * Representa uma "extensão" simples: um trecho de JavaScript que é injetado
 * automaticamente em toda página carregada (em qualquer aba) cujo domínio
 * combine com [pattern].
 *
 * pattern == "*"  -> roda em todos os sites, em todas as abas.
 * pattern == "meusite.com" -> roda só quando a URL contém esse trecho.
 */
data class Extension(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var pattern: String = "*",
    var code: String,
    var enabled: Boolean = true
) {
    fun matches(url: String?): Boolean {
        if (url == null) return false
        if (pattern.isBlank() || pattern == "*") return true
        return url.contains(pattern, ignoreCase = true)
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("pattern", pattern)
        put("code", code)
        put("enabled", enabled)
    }

    companion object {
        fun fromJson(obj: JSONObject): Extension = Extension(
            id = obj.optString("id", UUID.randomUUID().toString()),
            name = obj.optString("name", "Extensão"),
            pattern = obj.optString("pattern", "*"),
            code = obj.optString("code", ""),
            enabled = obj.optBoolean("enabled", true)
        )
    }
}
