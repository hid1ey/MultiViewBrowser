package com.userapp.multiviewbrowser

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader

class AddEditExtensionActivity : AppCompatActivity() {

    private lateinit var extensionManager: ExtensionManager
    private lateinit var inputName: EditText
    private lateinit var inputPattern: EditText
    private lateinit var inputCode: EditText

    private var editingId: String? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = result.data?.data
            if (uri != null) {
                try {
                    val inputStream = contentResolver.openInputStream(uri)
                    val text = inputStream?.bufferedReader().use { it?.readText() ?: "" }
                    inputCode.setText(text)
                    if (inputName.text.isBlank()) {
                        val fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "Extensão importada"
                        inputName.setText(fileName.removeSuffix(".js"))
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Não foi possível ler o arquivo: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_edit_extension)
        title = getString(R.string.add_extension_title)

        extensionManager = ExtensionManager.getInstance(this)

        inputName = findViewById(R.id.inputName)
        inputPattern = findViewById(R.id.inputPattern)
        inputCode = findViewById(R.id.inputCode)
        val btnImportFile = findViewById<Button>(R.id.btnImportFile)
        val btnSave = findViewById<Button>(R.id.btnSave)

        editingId = intent.getStringExtra(EXTRA_EXTENSION_ID)
        editingId?.let { id ->
            extensionManager.getAll().find { it.id == id }?.let { ext ->
                inputName.setText(ext.name)
                inputPattern.setText(ext.pattern)
                inputCode.setText(ext.code)
            }
        }

        btnImportFile.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/javascript", "application/javascript", "text/plain"))
            }
            filePicker.launch(intent)
        }

        btnSave.setOnClickListener { save() }
    }

    private fun save() {
        val name = inputName.text.toString().trim().ifBlank { "Extensão sem nome" }
        val pattern = inputPattern.text.toString().trim().ifBlank { "*" }
        val code = inputCode.text.toString()

        if (code.isBlank()) {
            Toast.makeText(this, "Cole ou importe o código JavaScript da extensão.", Toast.LENGTH_LONG).show()
            return
        }

        val existingId = editingId
        if (existingId != null) {
            extensionManager.update(Extension(id = existingId, name = name, pattern = pattern, code = code))
        } else {
            extensionManager.add(Extension(name = name, pattern = pattern, code = code))
        }

        Toast.makeText(this, "Extensão salva. Ela já vale em todas as abas abertas e novas.", Toast.LENGTH_LONG).show()
        finish()
    }

    companion object {
        const val EXTRA_EXTENSION_ID = "extra_extension_id"
    }
}
