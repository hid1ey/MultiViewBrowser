package com.userapp.multiviewbrowser

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var webViewContainer: FrameLayout
    private lateinit var tabStripContainer: LinearLayout
    private lateinit var addressBar: EditText
    private lateinit var backButton: ImageButton
    private lateinit var forwardButton: ImageButton
    private lateinit var reloadButton: ImageButton
    private lateinit var addTabButton: ImageButton
    private lateinit var extensionsButton: ImageButton

    private lateinit var extensionManager: ExtensionManager

    private val tabs = mutableListOf<BrowserTab>()
    private var currentTabId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        extensionManager = ExtensionManager.getInstance(this)

        webViewContainer = findViewById(R.id.webViewContainer)
        tabStripContainer = findViewById(R.id.tabStripContainer)
        addressBar = findViewById(R.id.addressBar)
        backButton = findViewById(R.id.backButton)
        forwardButton = findViewById(R.id.forwardButton)
        reloadButton = findViewById(R.id.reloadButton)
        addTabButton = findViewById(R.id.addTabButton)
        extensionsButton = findViewById(R.id.extensionsButton)

        addTabButton.setOnClickListener { createNewTab("https://www.google.com", switchTo = true) }
        extensionsButton.setOnClickListener {
            startActivity(Intent(this, ExtensionsActivity::class.java))
        }
        backButton.setOnClickListener { currentWebView()?.let { if (it.canGoBack()) it.goBack() } }
        forwardButton.setOnClickListener { currentWebView()?.let { if (it.canGoForward()) it.goForward() } }
        reloadButton.setOnClickListener { currentWebView()?.reload() }

        addressBar.setOnEditorActionListener { _, actionId, event ->
            val isGo = actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            if (isGo) {
                navigate(addressBar.text.toString())
                true
            } else {
                false
            }
        }

        if (tabs.isEmpty()) {
            createNewTab("https://www.google.com", switchTo = true)
        }
    }

    override fun onResume() {
        super.onResume()
        // Recarrega extensões em caso de terem sido editadas na tela de Extensões.
        // (ExtensionManager já é compartilhado/singleton, então isso é só por garantia visual.)
    }

    private fun currentWebView(): WebView? = tabs.find { it.id == currentTabId }?.webView

    // ---------------------------------------------------------------
    // Criação / configuração de abas
    // ---------------------------------------------------------------

    private fun createNewTab(initialUrl: String, switchTo: Boolean): BrowserTab {
        val id = UUID.randomUUID().toString()
        val webView = WebView(this)
        configureWebView(webView)

        val tab = BrowserTab(id, webView)
        tabs.add(tab)

        webView.loadUrl(initialUrl)

        renderTabStrip()
        if (switchTo) switchToTab(id)
        return tab
    }

    private fun configureWebView(webView: WebView) {
        webView.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.setSupportMultipleWindows(true)
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        webView.webViewClient = object : WebViewClient() {

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                // Primeira tentativa de injeção, logo no início da navegação.
                extensionManager.injectInto(view, url)
                if (findTabFor(view)?.id == currentTabId) {
                    addressBar.setText(url ?: "")
                }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                // Segunda injeção garantida após o carregamento completo —
                // cobre scripts que dependem do DOM já estar pronto.
                extensionManager.injectInto(view, url)

                findTabFor(view)?.let { tab ->
                    tab.url = url
                    tab.title = view.title?.takeIf { it.isNotBlank() } ?: (url ?: "Nova aba")
                    renderTabStrip()
                }

                if (findTabFor(view)?.id == currentTabId) {
                    updateNavButtons()
                    addressBar.setText(url ?: "")
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message
            ): Boolean {
                // target="_blank" ou window.open(): abre em uma nova aba própria,
                // que automaticamente também recebe as extensões instaladas.
                val newTab = createNewTab("about:blank", switchTo = true)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = newTab.webView
                resultMsg.sendToTarget()
                return true
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                super.onReceivedTitle(view, title)
                findTabFor(view)?.let { tab ->
                    tab.title = title?.takeIf { it.isNotBlank() } ?: tab.title
                    renderTabStrip()
                }
            }
        }
    }

    private fun findTabFor(webView: WebView): BrowserTab? = tabs.find { it.webView === webView }

    // ---------------------------------------------------------------
    // Troca / fechamento de abas
    // ---------------------------------------------------------------

    private fun switchToTab(id: String) {
        val tab = tabs.find { it.id == id } ?: return
        currentTabId = id

        webViewContainer.removeAllViews()
        (tab.webView.parent as? FrameLayout)?.removeView(tab.webView)
        webViewContainer.addView(tab.webView)

        addressBar.setText(tab.url ?: "")
        updateNavButtons()
        renderTabStrip()
    }

    private fun closeTab(id: String) {
        val idx = tabs.indexOfFirst { it.id == id }
        if (idx == -1) return
        val tab = tabs[idx]

        webViewContainer.removeView(tab.webView)
        tab.webView.destroy()
        tabs.removeAt(idx)

        if (tabs.isEmpty()) {
            createNewTab("https://www.google.com", switchTo = true)
            return
        }

        if (currentTabId == id) {
            val newIndex = if (idx > 0) idx - 1 else 0
            switchToTab(tabs[newIndex.coerceIn(0, tabs.size - 1)].id)
        } else {
            renderTabStrip()
        }
    }

    private fun updateNavButtons() {
        val wv = currentWebView()
        backButton.alpha = if (wv?.canGoBack() == true) 1f else 0.4f
        forwardButton.alpha = if (wv?.canGoForward() == true) 1f else 0.4f
    }

    // ---------------------------------------------------------------
    // Faixa de abas (UI)
    // ---------------------------------------------------------------

    private fun renderTabStrip() {
        tabStripContainer.removeAllViews()
        val inflater = layoutInflater
        for (tab in tabs) {
            val view = inflater.inflate(R.layout.item_tab, tabStripContainer, false)
            val root = view.findViewById<LinearLayout>(R.id.tabRoot)
            val titleView = view.findViewById<TextView>(R.id.tabTitle)
            val closeButton = view.findViewById<ImageButton>(R.id.tabCloseButton)

            titleView.text = tab.title
            root.setBackgroundColor(
                resources.getColor(
                    if (tab.id == currentTabId) R.color.tab_active else R.color.tab_inactive,
                    theme
                )
            )

            root.setOnClickListener { switchToTab(tab.id) }
            closeButton.setOnClickListener { closeTab(tab.id) }

            tabStripContainer.addView(view)
        }
    }

    // ---------------------------------------------------------------
    // Navegação a partir da barra de endereço
    // ---------------------------------------------------------------

    private fun navigate(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return

        val url = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            Patterns.WEB_URL.matcher(trimmed).matches() -> "https://$trimmed"
            else -> "https://www.google.com/search?q=" + android.net.Uri.encode(trimmed)
        }

        currentWebView()?.loadUrl(url)
        currentWebView()?.requestFocus()
        addressBar.clearFocus()
    }

    // ---------------------------------------------------------------
    // Botão físico/gesto de voltar do Android
    // ---------------------------------------------------------------

    override fun onBackPressed() {
        val wv = currentWebView()
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        for (tab in tabs) tab.webView.destroy()
        super.onDestroy()
    }
}
