package com.userapp.multiviewbrowser

import android.content.Context
import android.webkit.WebView
import org.json.JSONArray
import java.io.File

/**
 * Fonte única de verdade para as extensões instaladas.
 *
 * Qualquer aba (WebView) que chame [injectInto] receberá automaticamente
 * todos os scripts habilitados cujo padrão combine com a URL atual.
 * Isso é o que garante que uma extensão adicionada uma única vez passe
 * a valer em TODAS as telas/abas abertas, incluindo abas novas criadas
 * depois da extensão já estar instalada.
 */
class ExtensionManager private constructor(context: Context) {

    private val file: File = File(context.filesDir, "extensions.json")
    private val extensions = mutableListOf<Extension>()

    init {
        load()
    }

    @Synchronized
    fun getAll(): List<Extension> = extensions.toList()

    @Synchronized
    fun add(extension: Extension) {
        extensions.add(extension)
        save()
    }

    @Synchronized
    fun update(extension: Extension) {
        val idx = extensions.indexOfFirst { it.id == extension.id }
        if (idx >= 0) {
            extensions[idx] = extension
        } else {
            extensions.add(extension)
        }
        save()
    }

    @Synchronized
    fun remove(id: String) {
        extensions.removeAll { it.id == id }
        save()
    }

    @Synchronized
    fun setEnabled(id: String, enabled: Boolean) {
        extensions.find { it.id == id }?.let {
            it.enabled = enabled
            save()
        }
    }

    /**
     * Injeta todos os scripts habilitados e compatíveis com [url] na [webView]
     * fornecida. Deve ser chamado a partir de onPageFinished de QUALQUER aba —
     * cada aba tem sua própria WebView, então isso precisa ser chamado por
     * todas elas (o MainActivity já faz isso automaticamente para cada aba).
     */
    fun injectInto(webView: WebView, url: String?) {
        if (url == null) return
        for (ext in extensions) {
            if (ext.enabled && ext.matches(url) && ext.code.isNotBlank()) {
                val wrapped = "(function(){try{${ext.code}}catch(e){console.error('[Extensão ${ext.name}]', e);}})();"
                webView.evaluateJavascript(wrapped, null)
            }
        }
    }

    @Synchronized
    private fun load() {
        extensions.clear()
        if (!file.exists()) return
        try {
            val text = file.readText()
            val arr = JSONArray(text)
            for (i in 0 until arr.length()) {
                extensions.add(Extension.fromJson(arr.getJSONObject(i)))
            }
        } catch (_: Exception) {
            // arquivo corrompido ou vazio — começa do zero
        }
    }

    @Synchronized
    private fun save() {
        val arr = JSONArray()
        for (ext in extensions) arr.put(ext.toJson())
        file.writeText(arr.toString())
    }

    companion object {
        @Volatile private var instance: ExtensionManager? = null

        fun getInstance(context: Context): ExtensionManager =
            instance ?: synchronized(this) {
                instance ?: ExtensionManager(context.applicationContext).also { instance = it }
            }
    }
}
