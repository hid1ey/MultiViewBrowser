package com.userapp.multiviewbrowser

import android.webkit.WebView

class BrowserTab(
    val id: String,
    val webView: WebView
) {
    var title: String = "Nova aba"
    var url: String? = null
}
