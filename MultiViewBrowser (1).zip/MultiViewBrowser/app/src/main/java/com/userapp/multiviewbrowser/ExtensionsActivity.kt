package com.userapp.multiviewbrowser

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ExtensionsActivity : AppCompatActivity() {

    private lateinit var extensionManager: ExtensionManager
    private lateinit var adapter: ExtensionAdapter
    private lateinit var emptyText: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_extensions)
        title = getString(R.string.extensions_title)

        extensionManager = ExtensionManager.getInstance(this)

        val recycler = findViewById<RecyclerView>(R.id.extensionsRecycler)
        emptyText = findViewById(R.id.emptyText)
        val fab = findViewById<FloatingActionButton>(R.id.fabAddExtension)

        adapter = ExtensionAdapter(
            extensionManager.getAll().toMutableList(),
            onToggle = { ext, checked ->
                extensionManager.setEnabled(ext.id, checked)
            },
            onEdit = { ext ->
                val intent = Intent(this, AddEditExtensionActivity::class.java)
                intent.putExtra(AddEditExtensionActivity.EXTRA_EXTENSION_ID, ext.id)
                startActivity(intent)
            },
            onDelete = { ext ->
                AlertDialog.Builder(this)
                    .setTitle("Excluir extensão")
                    .setMessage("Remover \"${ext.name}\" de todas as abas?")
                    .setPositiveButton("Excluir") { _, _ ->
                        extensionManager.remove(ext.id)
                        refreshList()
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        )

        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        fab.setOnClickListener {
            startActivity(Intent(this, AddEditExtensionActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun refreshList() {
        val all = extensionManager.getAll()
        adapter.updateData(all)
        emptyText.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
    }
}
