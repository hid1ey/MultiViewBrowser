package com.userapp.multiviewbrowser

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.switchmaterial.SwitchMaterial

class ExtensionAdapter(
    private val items: MutableList<Extension>,
    private val onToggle: (Extension, Boolean) -> Unit,
    private val onEdit: (Extension) -> Unit,
    private val onDelete: (Extension) -> Unit
) : RecyclerView.Adapter<ExtensionAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.extName)
        val pattern: TextView = view.findViewById(R.id.extPattern)
        val switch: SwitchMaterial = view.findViewById(R.id.extSwitch)
        val editBtn: ImageButton = view.findViewById(R.id.btnEdit)
        val deleteBtn: ImageButton = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_extension, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ext = items[position]
        holder.name.text = ext.name
        holder.pattern.text = if (ext.pattern.isBlank() || ext.pattern == "*") "Todos os sites" else ext.pattern

        holder.switch.setOnCheckedChangeListener(null)
        holder.switch.isChecked = ext.enabled
        holder.switch.setOnCheckedChangeListener { _, checked -> onToggle(ext, checked) }

        holder.editBtn.setOnClickListener { onEdit(ext) }
        holder.deleteBtn.setOnClickListener { onDelete(ext) }
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<Extension>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}
